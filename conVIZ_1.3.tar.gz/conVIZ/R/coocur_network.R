coocur_network <-
function(dat){
  dat<-na.omit(dat)
  dat1<-t(dat)
  t_dat<-t(dat)
  t_dat<-as.data.frame(t_dat)
  library(igraph)
  mat.dat<- t(as.matrix(dat)) %*% as.matrix(dat) #create adjacency matrices, a square matrix where objects in rows and columns are the same.
  g <- graph.adjacency(mat.dat, weighted = T, mode = 'undirected', diag = TRUE)
  g <- simplify(g)
  st <- strength(g)
  # Set edge width based on weight and standardize the size:
  E(g)$width <- (E(g)$weight)/(sum(E(g)$weight))*30
  # Set node width based on frequency standardize the size:
  prc <- round(colSums(dat)/length(t_dat) * 100, 1)
  lendat<-nrow(dat)
  size<-round(lendat/500, 0)
  nodesize<-prc/size
  V(g)$degree <- degree(g)                      
  V(g)$strength <- strength(g)
  f<-colSums(dat)
  descriptive<-cbind(V(g)$degree, V(g)$strength, f, prc)
  colnames(descriptive)<-c("Degree", "Strength","Frequency", "Percentage")
  print(data.frame(descriptive))
  plot(g, 
       vertex.size = nodesize,
       vertex.frame.color = "black",
       vertex.color ="black",
       #vertex/nodes/circle LABEL
       vertex.label.dist=5,
       vertex.label.family="Helvetica",
       vertex.label.color="black",
       layout=layout_in_circle,
       #vertex/nodes/circle
       edge.color="gray",                           # Edge color
       edge.arrow.size=1,                            # Arrow size, defaults to 1
       edge.arrow.width=1)                           # Arrow width, defaults to 1
}
