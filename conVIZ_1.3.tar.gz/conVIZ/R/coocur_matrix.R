coocur_matrix <-
function(dat){
  if(is.character(dat)) stop("The parameters must be numbers")
  dat<-na.omit(dat)
  t_dat<-t(dat)
  t_dat<-as.data.frame(t_dat)
  mat1<- as.matrix(t_dat) %*% as.matrix(dat) 
  mat<-mat1
  mat[lower.tri(mat)] <- NA
  diag(mat)= NA
  print(mat)
}
