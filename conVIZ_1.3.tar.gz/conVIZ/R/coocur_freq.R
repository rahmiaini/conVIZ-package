coocur_freq <-
function(dat){
  if(is.character(dat)) stop("The parameters must be numbers")
  dat<-na.omit(dat)
  t_dat<-t(dat)
  t_dat<-as.data.frame(t_dat)
  sc<-colSums(dat)
  bar<-barplot(sc, las=2, col= "black",
               horiz = FALSE,
               main = "Frequency Plot ",
               ylab = "n",
               ylim=c(0,length(t_dat)))
  text(bar, y = sc, label = round(sc, 0), pos = 3, cex = 0.8, col = "black")
}
